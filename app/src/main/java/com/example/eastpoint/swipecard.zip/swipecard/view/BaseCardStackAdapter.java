package com.example.eastpoint.swipecard.view;

import android.widget.BaseAdapter;

import com.example.eastpoint.swipecard.model.CardModel;

import java.util.ArrayList;
import java.util.Collection;

public abstract class BaseCardStackAdapter extends BaseAdapter {

}
